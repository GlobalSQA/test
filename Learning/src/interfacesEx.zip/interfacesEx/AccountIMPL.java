package interfacesEx;

/**
 * Created by DELL on 07-08-2016.
 */
public class AccountIMPL {

    public static void main(String[] args) {

        SavingAccInterface acc = new SeniorCitizenSavingAcc();

    }
}
