package interfacesEx;

/**
 * Created by DELL on 07-08-2016.
 */
public interface BankAccount {

    public void kyc();
    public void atmCard();
    public void accountNo();
}
