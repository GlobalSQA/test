package interfacesEx;

/**
 * Created by DELL on 07-08-2016.
 */
public class SavingAcc implements BankAccount{


    @Override
    public void kyc() {

    }

    @Override
    public void atmCard() {

    }

    @Override
    public void accountNo() {

    }
    public void interestRate()
    {

    }
}
