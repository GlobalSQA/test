package interfacesEx;

/**
 * Created by DELL on 07-08-2016.
 */
public interface SavingAccInterface {

    public void interestRate();

}
